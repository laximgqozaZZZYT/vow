#!/usr/bin/env node
/**
 * Central Task Distribution Server
 * Manages tasks and agents across multiple machines via HTTP + SSE
 */

import express, { Request, Response, NextFunction } from "express";
import cors from "cors";
import { v4 as uuidv4 } from "uuid";
import {
  Task,
  Agent,
  TaskStatus,
  TaskPriority,
  AgentRole,
  AgentStatus,
  SSEEvent,
  SSEEventType,
  RegisterAgentRequest,
  CreateTaskRequest,
  AssignTaskRequest,
  SubmitResultRequest,
  ApiResponse,
  TrustedMachine,
  TrustLevel,
  TrustRequest,
  Project,
  LDAPConfig,
  InviteAgentRequest,
  AddTrustedMachineRequest,
} from "./types.js";

// Configuration
const PORT = parseInt(process.env.TASK_SERVER_PORT || "3456");
const HOST = process.env.TASK_SERVER_HOST || "0.0.0.0";
const AUTH_TOKEN = process.env.TASK_SERVER_TOKEN || "mcp-multi-agent-token-" + uuidv4().slice(0, 8);

// In-memory storage
const tasks = new Map<string, Task>();
const agents = new Map<string, Agent>();
const sseClients = new Map<string, Response>();

// Trust and project management storage
const trustedMachines = new Map<string, TrustedMachine>();
const trustRequests = new Map<string, TrustRequest>();
const projects = new Map<string, Project>();
const agentInvitations = new Map<string, { token: string; machineId: string; role: AgentRole; expiresAt: string }>();

// LDAP Configuration (can be set via API or env)
let ldapConfig: LDAPConfig = {
  enabled: process.env.LDAP_ENABLED === "true",
  url: process.env.LDAP_URL || "",
  baseDn: process.env.LDAP_BASE_DN || "",
  bindDn: process.env.LDAP_BIND_DN || "",
  bindPassword: process.env.LDAP_BIND_PASSWORD || "",
  userSearchFilter: process.env.LDAP_USER_FILTER || "(uid={0})",
  groupSearchFilter: process.env.LDAP_GROUP_FILTER || "(member={0})",
  agentGroupDn: process.env.LDAP_AGENT_GROUP || "",
  managerGroupDn: process.env.LDAP_MANAGER_GROUP || "",
};

// Initialize local machine as trusted
const LOCAL_MACHINE_ID = `machine-${uuidv4().slice(0, 8)}`;
trustedMachines.set(LOCAL_MACHINE_ID, {
  id: LOCAL_MACHINE_ID,
  hostname: process.env.HOSTNAME || "localhost",
  ipAddress: "127.0.0.1",
  trustLevel: "full",
  authMethod: "token",
  addedBy: "system",
  addedAt: getCurrentTimestamp(),
  lastSeen: getCurrentTimestamp(),
  maxAgents: 20,
  currentAgents: 0,
  isOnline: true,
});

// Helper functions
function getCurrentTimestamp(): string {
  return new Date().toISOString();
}

function broadcast(event: SSEEvent): void {
  const data = `data: ${JSON.stringify(event)}\n\n`;
  sseClients.forEach((client) => {
    client.write(data);
  });
}

function emitEvent(type: SSEEventType, data: unknown): void {
  broadcast({
    type,
    timestamp: getCurrentTimestamp(),
    data,
  });
}

// Express app setup
const app = express();
app.use(cors());
app.use(express.json());

// Auth middleware
function authMiddleware(req: Request, res: Response, next: NextFunction): void {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (token !== AUTH_TOKEN) {
    res.status(401).json({ success: false, error: "Unauthorized" });
    return;
  }
  next();
}

// Check if agent is a manager
function isManager(agentId: string): boolean {
  const agent = agents.get(agentId);
  return agent?.role === "manager";
}

// Manager-only middleware
function managerMiddleware(req: Request, res: Response, next: NextFunction): void {
  const agentId = req.headers["x-agent-id"] as string;
  if (!agentId) {
    res.status(400).json({ success: false, error: "X-Agent-ID header required" });
    return;
  }
  if (!isManager(agentId)) {
    res.status(403).json({ success: false, error: "Manager role required" });
    return;
  }
  next();
}

// Trust verification
function verifyMachineTrust(machineId: string, requiredLevel: TrustLevel = "basic"): boolean {
  const machine = trustedMachines.get(machineId);
  if (!machine || !machine.isOnline) return false;

  const trustHierarchy: TrustLevel[] = ["none", "basic", "elevated", "full"];
  const machineLevel = trustHierarchy.indexOf(machine.trustLevel);
  const requiredLevelIndex = trustHierarchy.indexOf(requiredLevel);

  return machineLevel >= requiredLevelIndex;
}

// Get machine from IP
function getMachineByIp(ip: string): TrustedMachine | undefined {
  return Array.from(trustedMachines.values()).find(m => m.ipAddress === ip || m.ipAddress === "127.0.0.1");
}

// LDAP authentication (placeholder - would need actual ldapjs implementation)
async function verifyLdapCredentials(username: string, password: string): Promise<boolean> {
  if (!ldapConfig.enabled) return false;

  // In production, use ldapjs library:
  // const ldap = require('ldapjs');
  // const client = ldap.createClient({ url: ldapConfig.url });
  // ... bind and search

  console.log(`LDAP auth attempt for: ${username}`);
  return false; // Placeholder
}

// Generate invitation token
function generateInvitationToken(): string {
  return `invite-${uuidv4()}`;
}

// Health check (no auth required)
app.get("/health", (_req, res) => {
  res.json({
    success: true,
    data: {
      status: "running",
      timestamp: getCurrentTimestamp(),
      agents: agents.size,
      tasks: tasks.size,
    },
  });
});

// SSE endpoint for real-time updates
app.get("/events", authMiddleware, (req, res) => {
  const clientId = uuidv4();

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  // Send initial connection event
  res.write(`data: ${JSON.stringify({ type: "connected", clientId })}\n\n`);

  sseClients.set(clientId, res);

  req.on("close", () => {
    sseClients.delete(clientId);
  });
});

// ============ Agent Management ============

// Register a new agent
app.post("/agents/register", authMiddleware, (req, res) => {
  const { name, role, capabilities, machineId } = req.body as RegisterAgentRequest;

  if (!name || !role || !machineId) {
    res.status(400).json({ success: false, error: "name, role, and machineId are required" });
    return;
  }

  const agentId = `agent-${uuidv4().slice(0, 8)}`;
  const now = getCurrentTimestamp();

  const agent: Agent = {
    id: agentId,
    name,
    role: role as AgentRole,
    capabilities: capabilities || [],
    status: "idle",
    currentTaskId: null,
    machineId,
    lastHeartbeat: now,
    registeredAt: now,
  };

  agents.set(agentId, agent);
  emitEvent("agent_registered", agent);

  res.json({ success: true, data: { agentId, token: AUTH_TOKEN } } as ApiResponse);
});

// List all agents
app.get("/agents", authMiddleware, (_req, res) => {
  const agentList = Array.from(agents.values());
  res.json({ success: true, data: agentList } as ApiResponse);
});

// Get agent by ID
app.get("/agents/:id", authMiddleware, (req: Request<{ id: string }>, res) => {
  const agent = agents.get(req.params.id);
  if (!agent) {
    res.status(404).json({ success: false, error: "Agent not found" });
    return;
  }
  res.json({ success: true, data: agent } as ApiResponse);
});

// Update agent status / heartbeat
app.post("/agents/:id/heartbeat", authMiddleware, (req: Request<{ id: string }>, res) => {
  const agent = agents.get(req.params.id);
  if (!agent) {
    res.status(404).json({ success: false, error: "Agent not found" });
    return;
  }

  const oldStatus = agent.status;
  agent.lastHeartbeat = getCurrentTimestamp();

  if (req.body.status && ["idle", "busy", "offline"].includes(req.body.status)) {
    agent.status = req.body.status as AgentStatus;
  }

  if (oldStatus !== agent.status) {
    emitEvent("agent_status_changed", { agentId: agent.id, oldStatus, newStatus: agent.status });
  }

  res.json({ success: true, data: agent } as ApiResponse);
});

// Unregister agent
app.delete("/agents/:id", authMiddleware, (req: Request<{ id: string }>, res) => {
  const agent = agents.get(req.params.id);
  if (!agent) {
    res.status(404).json({ success: false, error: "Agent not found" });
    return;
  }

  agents.delete(req.params.id);
  res.json({ success: true, data: { message: `Agent ${req.params.id} unregistered` } } as ApiResponse);
});

// ============ Task Management ============

// Create a new task
app.post("/tasks", authMiddleware, (req, res) => {
  const {
    title,
    description,
    priority = "normal",
    tags = [],
    parentTaskId,
    assignTo,
    deadline,
  } = req.body as CreateTaskRequest;

  if (!title || !description) {
    res.status(400).json({ success: false, error: "title and description are required" });
    return;
  }

  const creatorId = req.headers["x-agent-id"] as string || "system";
  const taskId = `task-${uuidv4().slice(0, 8)}`;
  const now = getCurrentTimestamp();

  const task: Task = {
    id: taskId,
    title,
    description,
    priority: priority as TaskPriority,
    assignedTo: assignTo || null,
    status: assignTo ? "assigned" : "pending",
    result: null,
    tags,
    parentTaskId: parentTaskId || null,
    createdBy: creatorId,
    createdAt: now,
    updatedAt: now,
    deadline: deadline || null,
  };

  tasks.set(taskId, task);
  emitEvent("task_created", task);

  if (assignTo) {
    const agent = agents.get(assignTo);
    if (agent) {
      emitEvent("task_assigned", { taskId, agentId: assignTo });
    }
  }

  res.json({ success: true, data: task } as ApiResponse);
});

// List tasks with optional filters
app.get("/tasks", authMiddleware, (req, res) => {
  let taskList = Array.from(tasks.values());

  // Filter by status
  if (req.query.status) {
    const statuses = (req.query.status as string).split(",");
    taskList = taskList.filter((t) => statuses.includes(t.status));
  }

  // Filter by assignee
  if (req.query.assignedTo) {
    const assignedTo = req.query.assignedTo as string;
    taskList = taskList.filter((t) => t.assignedTo === assignedTo);
  }

  // Filter by tag
  if (req.query.tag) {
    taskList = taskList.filter((t) => t.tags.includes(req.query.tag as string));
  }

  // Sort by priority and creation time
  const priorityOrder: Record<TaskPriority, number> = { urgent: 0, high: 1, normal: 2, low: 3 };
  taskList.sort((a, b) => {
    const pDiff = priorityOrder[a.priority] - priorityOrder[b.priority];
    if (pDiff !== 0) return pDiff;
    return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
  });

  res.json({ success: true, data: taskList } as ApiResponse);
});

// Get task by ID
app.get("/tasks/:id", authMiddleware, (req: Request<{ id: string }>, res) => {
  const task = tasks.get(req.params.id);
  if (!task) {
    res.status(404).json({ success: false, error: "Task not found" });
    return;
  }
  res.json({ success: true, data: task } as ApiResponse);
});

// Assign task to agent
app.post("/tasks/:id/assign", authMiddleware, (req: Request<{ id: string }>, res) => {
  const { agentId } = req.body as { agentId: string };
  const task = tasks.get(req.params.id);

  if (!task) {
    res.status(404).json({ success: false, error: "Task not found" });
    return;
  }

  const agent = agents.get(agentId);
  if (!agent) {
    res.status(404).json({ success: false, error: "Agent not found" });
    return;
  }

  task.assignedTo = agentId;
  task.status = "assigned";
  task.updatedAt = getCurrentTimestamp();

  emitEvent("task_assigned", { taskId: task.id, agentId });

  res.json({ success: true, data: task } as ApiResponse);
});

// Claim/start a task (agent calls this)
app.post("/tasks/:id/claim", authMiddleware, (req: Request<{ id: string }>, res) => {
  const agentId = req.headers["x-agent-id"] as string;
  const task = tasks.get(req.params.id);

  if (!task) {
    res.status(404).json({ success: false, error: "Task not found" });
    return;
  }

  if (!agentId) {
    res.status(400).json({ success: false, error: "x-agent-id header required" });
    return;
  }

  // Allow claiming if unassigned or assigned to this agent
  if (task.assignedTo && task.assignedTo !== agentId) {
    res.status(403).json({ success: false, error: "Task is assigned to another agent" });
    return;
  }

  if (task.status !== "pending" && task.status !== "assigned") {
    res.status(400).json({ success: false, error: `Cannot claim task with status: ${task.status}` });
    return;
  }

  const agent = agents.get(agentId);
  if (agent) {
    agent.status = "busy";
    agent.currentTaskId = task.id;
  }

  task.assignedTo = agentId;
  task.status = "in_progress";
  task.updatedAt = getCurrentTimestamp();

  emitEvent("task_started", { taskId: task.id, agentId });

  res.json({ success: true, data: task } as ApiResponse);
});

// Submit task result
app.post("/tasks/:id/submit", authMiddleware, (req: Request<{ id: string }>, res) => {
  const { result, success } = req.body as SubmitResultRequest;
  const agentId = req.headers["x-agent-id"] as string;
  const task = tasks.get(req.params.id);

  if (!task) {
    res.status(404).json({ success: false, error: "Task not found" });
    return;
  }

  if (!result) {
    res.status(400).json({ success: false, error: "result is required" });
    return;
  }

  task.result = result;
  task.status = success ? "completed" : "failed";
  task.updatedAt = getCurrentTimestamp();

  // Update agent status
  if (agentId) {
    const agent = agents.get(agentId);
    if (agent) {
      agent.status = "idle";
      agent.currentTaskId = null;
    }
  }

  emitEvent(success ? "task_completed" : "task_failed", {
    taskId: task.id,
    agentId,
    result: result.slice(0, 200), // Truncate for event
  });

  res.json({ success: true, data: task } as ApiResponse);
});

// Delete task
app.delete("/tasks/:id", authMiddleware, (req: Request<{ id: string }>, res) => {
  const task = tasks.get(req.params.id);
  if (!task) {
    res.status(404).json({ success: false, error: "Task not found" });
    return;
  }

  tasks.delete(req.params.id);
  res.json({ success: true, data: { message: `Task ${req.params.id} deleted` } } as ApiResponse);
});

// ============ Dashboard / Stats ============

app.get("/dashboard", authMiddleware, (_req, res) => {
  const allTasks = Array.from(tasks.values());
  const allAgents = Array.from(agents.values());

  const stats = {
    timestamp: getCurrentTimestamp(),
    tasks: {
      total: allTasks.length,
      pending: allTasks.filter((t) => t.status === "pending").length,
      assigned: allTasks.filter((t) => t.status === "assigned").length,
      in_progress: allTasks.filter((t) => t.status === "in_progress").length,
      completed: allTasks.filter((t) => t.status === "completed").length,
      failed: allTasks.filter((t) => t.status === "failed").length,
    },
    agents: {
      total: allAgents.length,
      idle: allAgents.filter((a) => a.status === "idle").length,
      busy: allAgents.filter((a) => a.status === "busy").length,
      offline: allAgents.filter((a) => a.status === "offline").length,
      byRole: {} as Record<string, number>,
      byMachine: {} as Record<string, number>,
    },
    recentTasks: allTasks
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
      .slice(0, 10)
      .map((t) => ({
        id: t.id,
        title: t.title,
        status: t.status,
        assignedTo: t.assignedTo,
      })),
  };

  // Count by role
  allAgents.forEach((a) => {
    stats.agents.byRole[a.role] = (stats.agents.byRole[a.role] || 0) + 1;
    stats.agents.byMachine[a.machineId] = (stats.agents.byMachine[a.machineId] || 0) + 1;
  });

  res.json({ success: true, data: stats } as ApiResponse);
});

// ============ Manager: Trust Management ============

// List trusted machines
app.get("/trust/machines", authMiddleware, managerMiddleware, (_req, res) => {
  const machines = Array.from(trustedMachines.values());
  res.json({ success: true, data: machines } as ApiResponse);
});

// Add trusted machine
app.post("/trust/machines", authMiddleware, managerMiddleware, (req, res) => {
  const {
    hostname,
    ipAddress,
    trustLevel = "basic",
    authMethod = "token",
    maxAgents = 10,
    publicKey,
    ldapDn,
  } = req.body as AddTrustedMachineRequest;

  if (!hostname || !ipAddress) {
    res.status(400).json({ success: false, error: "hostname and ipAddress are required" });
    return;
  }

  // Check if already exists
  const existing = Array.from(trustedMachines.values()).find(
    m => m.ipAddress === ipAddress || m.hostname === hostname
  );
  if (existing) {
    res.status(409).json({ success: false, error: "Machine already registered" });
    return;
  }

  const agentId = req.headers["x-agent-id"] as string;
  const machineId = `machine-${uuidv4().slice(0, 8)}`;

  const machine: TrustedMachine = {
    id: machineId,
    hostname,
    ipAddress,
    trustLevel: trustLevel as TrustLevel,
    authMethod,
    publicKey,
    ldapDn,
    addedBy: agentId,
    addedAt: getCurrentTimestamp(),
    lastSeen: getCurrentTimestamp(),
    maxAgents,
    currentAgents: 0,
    isOnline: false,
  };

  trustedMachines.set(machineId, machine);
  emitEvent("agent_registered", { type: "machine_trusted", machine });

  res.json({ success: true, data: machine } as ApiResponse);
});

// Update machine trust
app.patch("/trust/machines/:id", authMiddleware, managerMiddleware, (req: Request<{ id: string }>, res) => {
  const machine = trustedMachines.get(req.params.id);
  if (!machine) {
    res.status(404).json({ success: false, error: "Machine not found" });
    return;
  }

  const { trustLevel, maxAgents, enabled } = req.body;

  if (trustLevel) machine.trustLevel = trustLevel;
  if (maxAgents !== undefined) machine.maxAgents = maxAgents;
  if (enabled !== undefined) machine.isOnline = enabled;

  res.json({ success: true, data: machine } as ApiResponse);
});

// Remove trusted machine
app.delete("/trust/machines/:id", authMiddleware, managerMiddleware, (req: Request<{ id: string }>, res) => {
  const machine = trustedMachines.get(req.params.id);
  if (!machine) {
    res.status(404).json({ success: false, error: "Machine not found" });
    return;
  }

  // Don't allow removing the local machine
  if (machine.id === LOCAL_MACHINE_ID) {
    res.status(403).json({ success: false, error: "Cannot remove local machine" });
    return;
  }

  // Remove all agents from this machine
  const machineAgents = Array.from(agents.values()).filter(a => a.machineId === machine.id);
  machineAgents.forEach(a => agents.delete(a.id));

  trustedMachines.delete(req.params.id);

  res.json({
    success: true,
    data: {
      message: `Machine ${machine.hostname} removed`,
      removedAgents: machineAgents.length,
    },
  } as ApiResponse);
});

// ============ Manager: Agent Management ============

// Invite agent (generate invitation for remote machine)
app.post("/agents/invite", authMiddleware, managerMiddleware, (req, res) => {
  const { machineId, agentName, role, capabilities = [] } = req.body as InviteAgentRequest;

  const machine = trustedMachines.get(machineId);
  if (!machine) {
    res.status(404).json({ success: false, error: "Machine not found" });
    return;
  }

  if (!verifyMachineTrust(machineId, "basic")) {
    res.status(403).json({ success: false, error: "Machine not trusted or offline" });
    return;
  }

  if (machine.currentAgents >= machine.maxAgents) {
    res.status(400).json({ success: false, error: "Machine has reached max agents" });
    return;
  }

  const token = generateInvitationToken();
  const expiresAt = new Date(Date.now() + 3600000).toISOString(); // 1 hour

  agentInvitations.set(token, {
    token,
    machineId,
    role: role as AgentRole,
    expiresAt,
  });

  res.json({
    success: true,
    data: {
      invitationToken: token,
      machineId,
      agentName,
      role,
      expiresAt,
      instructions: `On the remote machine, run: claude with AGENT_INVITATION_TOKEN=${token}`,
    },
  } as ApiResponse);
});

// Remove agent (manager can remove any agent)
app.delete("/agents/:id/remove", authMiddleware, managerMiddleware, (req: Request<{ id: string }>, res) => {
  const agent = agents.get(req.params.id);
  if (!agent) {
    res.status(404).json({ success: false, error: "Agent not found" });
    return;
  }

  const managerId = req.headers["x-agent-id"] as string;

  // Don't allow removing yourself
  if (agent.id === managerId) {
    res.status(403).json({ success: false, error: "Cannot remove yourself" });
    return;
  }

  // Update machine agent count
  const machine = trustedMachines.get(agent.machineId);
  if (machine) {
    machine.currentAgents = Math.max(0, machine.currentAgents - 1);
  }

  // Unassign any tasks
  tasks.forEach(task => {
    if (task.assignedTo === agent.id) {
      task.assignedTo = null;
      task.status = "pending";
    }
  });

  agents.delete(req.params.id);
  emitEvent("agent_status_changed", { agentId: agent.id, status: "removed", removedBy: managerId });

  res.json({
    success: true,
    data: { message: `Agent ${agent.name} removed` },
  } as ApiResponse);
});

// Register agent with invitation token
app.post("/agents/register-with-invitation", authMiddleware, (req, res) => {
  const { invitationToken, name, capabilities = [] } = req.body;

  const invitation = agentInvitations.get(invitationToken);
  if (!invitation) {
    res.status(401).json({ success: false, error: "Invalid invitation token" });
    return;
  }

  if (new Date(invitation.expiresAt) < new Date()) {
    agentInvitations.delete(invitationToken);
    res.status(401).json({ success: false, error: "Invitation token expired" });
    return;
  }

  const machine = trustedMachines.get(invitation.machineId);
  if (!machine || !verifyMachineTrust(invitation.machineId)) {
    res.status(403).json({ success: false, error: "Machine trust revoked" });
    return;
  }

  const agentId = `agent-${uuidv4().slice(0, 8)}`;
  const now = getCurrentTimestamp();

  const agent: Agent = {
    id: agentId,
    name: name || `Invited-${agentId.slice(-4)}`,
    role: invitation.role,
    capabilities,
    status: "idle",
    currentTaskId: null,
    machineId: invitation.machineId,
    lastHeartbeat: now,
    registeredAt: now,
  };

  agents.set(agentId, agent);
  machine.currentAgents++;
  machine.lastSeen = now;

  // Remove used invitation
  agentInvitations.delete(invitationToken);

  emitEvent("agent_registered", agent);

  res.json({ success: true, data: { agentId, token: AUTH_TOKEN } } as ApiResponse);
});

// ============ Manager: Project Management ============

// List projects
app.get("/projects", authMiddleware, (_req, res) => {
  const projectList = Array.from(projects.values());
  res.json({ success: true, data: projectList } as ApiResponse);
});

// Create project
app.post("/projects", authMiddleware, managerMiddleware, (req, res) => {
  const { name, path, description, settings } = req.body;

  if (!name || !path) {
    res.status(400).json({ success: false, error: "name and path are required" });
    return;
  }

  const agentId = req.headers["x-agent-id"] as string;
  const projectId = `project-${uuidv4().slice(0, 8)}`;
  const now = getCurrentTimestamp();

  const project: Project = {
    id: projectId,
    name,
    path,
    description,
    createdBy: agentId,
    createdAt: now,
    updatedAt: now,
    settings: {
      maxAgents: 20,
      allowRemoteAgents: true,
      requiredTrustLevel: "basic",
      autoAssignTasks: false,
      defaultAgentRoles: ["developer", "tester"],
      ...settings,
    },
  };

  projects.set(projectId, project);

  res.json({ success: true, data: project } as ApiResponse);
});

// ============ Manager: LDAP Configuration ============

// Get LDAP config (masked password)
app.get("/config/ldap", authMiddleware, managerMiddleware, (_req, res) => {
  res.json({
    success: true,
    data: {
      ...ldapConfig,
      bindPassword: ldapConfig.bindPassword ? "********" : "",
    },
  } as ApiResponse);
});

// Update LDAP config
app.put("/config/ldap", authMiddleware, managerMiddleware, (req, res) => {
  const newConfig = req.body as Partial<LDAPConfig>;

  ldapConfig = {
    ...ldapConfig,
    ...newConfig,
  };

  res.json({
    success: true,
    data: {
      ...ldapConfig,
      bindPassword: ldapConfig.bindPassword ? "********" : "",
    },
  } as ApiResponse);
});

// Test LDAP connection
app.post("/config/ldap/test", authMiddleware, managerMiddleware, async (_req, res) => {
  if (!ldapConfig.enabled) {
    res.json({ success: false, error: "LDAP not enabled" });
    return;
  }

  // In production, actually test the connection
  res.json({
    success: true,
    data: { message: "LDAP connection test placeholder - implement with ldapjs" },
  } as ApiResponse);
});

// ============ Extended Dashboard for Managers ============

app.get("/dashboard/extended", authMiddleware, managerMiddleware, (_req, res) => {
  const allTasks = Array.from(tasks.values());
  const allAgents = Array.from(agents.values());
  const allMachines = Array.from(trustedMachines.values());
  const allProjects = Array.from(projects.values());

  const stats = {
    timestamp: getCurrentTimestamp(),
    tasks: {
      total: allTasks.length,
      byStatus: {
        pending: allTasks.filter(t => t.status === "pending").length,
        assigned: allTasks.filter(t => t.status === "assigned").length,
        in_progress: allTasks.filter(t => t.status === "in_progress").length,
        completed: allTasks.filter(t => t.status === "completed").length,
        failed: allTasks.filter(t => t.status === "failed").length,
      },
    },
    agents: {
      total: allAgents.length,
      byStatus: {
        idle: allAgents.filter(a => a.status === "idle").length,
        busy: allAgents.filter(a => a.status === "busy").length,
        offline: allAgents.filter(a => a.status === "offline").length,
      },
      byRole: {} as Record<string, number>,
      byMachine: {} as Record<string, { name: string; count: number }>,
    },
    machines: {
      total: allMachines.length,
      online: allMachines.filter(m => m.isOnline).length,
      byTrustLevel: {} as Record<string, number>,
      totalCapacity: allMachines.reduce((sum, m) => sum + m.maxAgents, 0),
      usedCapacity: allMachines.reduce((sum, m) => sum + m.currentAgents, 0),
    },
    projects: {
      total: allProjects.length,
    },
    ldap: {
      enabled: ldapConfig.enabled,
      url: ldapConfig.url || null,
    },
  };

  // Aggregate counts
  allAgents.forEach(a => {
    stats.agents.byRole[a.role] = (stats.agents.byRole[a.role] || 0) + 1;

    const machine = trustedMachines.get(a.machineId);
    if (machine) {
      if (!stats.agents.byMachine[a.machineId]) {
        stats.agents.byMachine[a.machineId] = { name: machine.hostname, count: 0 };
      }
      stats.agents.byMachine[a.machineId].count++;
    }
  });

  allMachines.forEach(m => {
    stats.machines.byTrustLevel[m.trustLevel] = (stats.machines.byTrustLevel[m.trustLevel] || 0) + 1;
  });

  res.json({ success: true, data: stats } as ApiResponse);
});

// Start server
app.listen(PORT, HOST, () => {
  console.log("=".repeat(60));
  console.log("  Task Distribution Server v2.0");
  console.log("=".repeat(60));
  console.log(`  Status:    Running`);
  console.log(`  Host:      ${HOST}`);
  console.log(`  Port:      ${PORT}`);
  console.log(`  URL:       http://${HOST === "0.0.0.0" ? "localhost" : HOST}:${PORT}`);
  console.log("");
  console.log(`  Auth Token: ${AUTH_TOKEN}`);
  console.log("");
  console.log("  Endpoints:");
  console.log("    GET  /health          - Health check");
  console.log("    GET  /events          - SSE event stream");
  console.log("    GET  /dashboard       - Statistics dashboard");
  console.log("    POST /agents/register - Register new agent");
  console.log("    GET  /agents          - List all agents");
  console.log("    POST /tasks           - Create new task");
  console.log("    GET  /tasks           - List tasks");
  console.log("    POST /tasks/:id/claim - Claim a task");
  console.log("    POST /tasks/:id/submit- Submit result");
  console.log("=".repeat(60));
});
