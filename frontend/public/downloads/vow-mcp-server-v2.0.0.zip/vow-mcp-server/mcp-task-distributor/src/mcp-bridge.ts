#!/usr/bin/env node
/**
 * MCP Bridge - Local MCP server that communicates with central Task Server
 * Each Claude Code instance runs this locally
 */

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";
import { v4 as uuidv4 } from "uuid";

// Configuration from environment
const SERVER_URL = process.env.TASK_SERVER_URL || "http://localhost:3456";
const AUTH_TOKEN = process.env.TASK_SERVER_TOKEN || "";
const AGENT_ID = process.env.AGENT_ID || "";
const AGENT_NAME = process.env.AGENT_NAME || "Unnamed Agent";
const AGENT_ROLE = process.env.AGENT_ROLE || "general";
const MACHINE_ID = process.env.MACHINE_ID || `machine-${uuidv4().slice(0, 8)}`;

// Registered agent info
let registeredAgentId: string | null = AGENT_ID || null;

// HTTP client helper
async function apiCall<T>(
  method: string,
  path: string,
  body?: unknown
): Promise<{ success: boolean; data?: T; error?: string }> {
  try {
    const response = await fetch(`${SERVER_URL}${path}`, {
      method,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${AUTH_TOKEN}`,
        ...(registeredAgentId ? { "X-Agent-ID": registeredAgentId } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    const result = await response.json();
    return result as { success: boolean; data?: T; error?: string };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    };
  }
}

// Create MCP Server
const server = new Server(
  {
    name: "task-distributor-bridge",
    version: "2.0.0",
  },
  {
    capabilities: {
      tools: {},
      resources: {},
    },
  }
);

// List available tools
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      // Agent management
      {
        name: "register_agent",
        description:
          "Register this agent with the central task server. Required before using other tools. Returns agent ID.",
        inputSchema: {
          type: "object",
          properties: {
            name: {
              type: "string",
              description: "Display name for this agent",
            },
            role: {
              type: "string",
              enum: ["manager", "developer", "reviewer", "tester", "documenter", "analyst", "architect", "devops", "general"],
              description: "Role/specialization of this agent",
            },
            capabilities: {
              type: "array",
              items: { type: "string" },
              description: "List of capabilities (e.g., ['python', 'react', 'testing'])",
            },
          },
          required: ["name", "role"],
        },
      },
      {
        name: "heartbeat",
        description: "Send heartbeat to server and update status. Call periodically to stay registered.",
        inputSchema: {
          type: "object",
          properties: {
            status: {
              type: "string",
              enum: ["idle", "busy"],
              description: "Current status (default: idle)",
            },
          },
        },
      },
      {
        name: "list_agents",
        description: "List all registered agents and their status",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },

      // Task management (Manager tools)
      {
        name: "create_task",
        description: "Create a new task. Managers use this to delegate work.",
        inputSchema: {
          type: "object",
          properties: {
            title: {
              type: "string",
              description: "Brief title of the task",
            },
            description: {
              type: "string",
              description: "Detailed description of what needs to be done",
            },
            priority: {
              type: "string",
              enum: ["low", "normal", "high", "urgent"],
              description: "Task priority (default: normal)",
            },
            tags: {
              type: "array",
              items: { type: "string" },
              description: "Tags for categorization",
            },
            assign_to: {
              type: "string",
              description: "Agent ID to assign this task to (optional)",
            },
          },
          required: ["title", "description"],
        },
      },
      {
        name: "assign_task",
        description: "Assign an existing task to a specific agent",
        inputSchema: {
          type: "object",
          properties: {
            task_id: {
              type: "string",
              description: "ID of the task to assign",
            },
            agent_id: {
              type: "string",
              description: "ID of the agent to assign to",
            },
          },
          required: ["task_id", "agent_id"],
        },
      },
      {
        name: "list_tasks",
        description: "List tasks with optional filters",
        inputSchema: {
          type: "object",
          properties: {
            status: {
              type: "string",
              description: "Filter by status (comma-separated: pending,assigned,in_progress,completed,failed)",
            },
            assigned_to: {
              type: "string",
              description: "Filter by assigned agent ID",
            },
            tag: {
              type: "string",
              description: "Filter by tag",
            },
          },
        },
      },
      {
        name: "get_task",
        description: "Get detailed information about a specific task",
        inputSchema: {
          type: "object",
          properties: {
            task_id: {
              type: "string",
              description: "ID of the task",
            },
          },
          required: ["task_id"],
        },
      },

      // Worker tools
      {
        name: "get_my_tasks",
        description: "Get all tasks assigned to this agent",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },
      {
        name: "claim_task",
        description: "Claim a task and mark it as in progress. Call this before starting work.",
        inputSchema: {
          type: "object",
          properties: {
            task_id: {
              type: "string",
              description: "ID of the task to claim",
            },
          },
          required: ["task_id"],
        },
      },
      {
        name: "submit_result",
        description: "Submit the result of a completed task",
        inputSchema: {
          type: "object",
          properties: {
            task_id: {
              type: "string",
              description: "ID of the task",
            },
            result: {
              type: "string",
              description: "The result/output of the task",
            },
            success: {
              type: "boolean",
              description: "Whether the task was completed successfully",
            },
          },
          required: ["task_id", "result", "success"],
        },
      },

      // Dashboard
      {
        name: "dashboard",
        description: "Get an overview of all tasks and agents (statistics)",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },

      // ============ Manager-only Tools ============

      // Trust Management
      {
        name: "list_trusted_machines",
        description: "[Manager] List all trusted machines that can run agents",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },
      {
        name: "add_trusted_machine",
        description: "[Manager] Add a new machine to the trust list, allowing it to run agents",
        inputSchema: {
          type: "object",
          properties: {
            hostname: {
              type: "string",
              description: "Hostname of the machine",
            },
            ip_address: {
              type: "string",
              description: "IP address of the machine",
            },
            trust_level: {
              type: "string",
              enum: ["basic", "elevated", "full"],
              description: "Trust level (basic=limited agents, elevated=more agents, full=unlimited)",
            },
            auth_method: {
              type: "string",
              enum: ["token", "ldap", "certificate"],
              description: "Authentication method for this machine",
            },
            max_agents: {
              type: "number",
              description: "Maximum number of agents allowed on this machine",
            },
          },
          required: ["hostname", "ip_address"],
        },
      },
      {
        name: "update_machine_trust",
        description: "[Manager] Update trust settings for a machine",
        inputSchema: {
          type: "object",
          properties: {
            machine_id: {
              type: "string",
              description: "ID of the machine to update",
            },
            trust_level: {
              type: "string",
              enum: ["none", "basic", "elevated", "full"],
              description: "New trust level",
            },
            max_agents: {
              type: "number",
              description: "New max agents limit",
            },
            enabled: {
              type: "boolean",
              description: "Enable or disable the machine",
            },
          },
          required: ["machine_id"],
        },
      },
      {
        name: "remove_trusted_machine",
        description: "[Manager] Remove a machine from trust list and disconnect all its agents",
        inputSchema: {
          type: "object",
          properties: {
            machine_id: {
              type: "string",
              description: "ID of the machine to remove",
            },
          },
          required: ["machine_id"],
        },
      },

      // Agent Management (Manager)
      {
        name: "invite_agent",
        description: "[Manager] Generate an invitation for a new agent on a trusted machine",
        inputSchema: {
          type: "object",
          properties: {
            machine_id: {
              type: "string",
              description: "ID of the machine where agent will run",
            },
            agent_name: {
              type: "string",
              description: "Name for the new agent",
            },
            role: {
              type: "string",
              enum: ["developer", "reviewer", "tester", "documenter", "analyst", "architect", "devops", "general"],
              description: "Role for the new agent",
            },
          },
          required: ["machine_id", "agent_name", "role"],
        },
      },
      {
        name: "remove_agent",
        description: "[Manager] Remove an agent from the system",
        inputSchema: {
          type: "object",
          properties: {
            agent_id: {
              type: "string",
              description: "ID of the agent to remove",
            },
            reason: {
              type: "string",
              description: "Reason for removal (optional)",
            },
          },
          required: ["agent_id"],
        },
      },

      // Project Management
      {
        name: "list_projects",
        description: "[Manager] List all registered projects",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },
      {
        name: "create_project",
        description: "[Manager] Register a new project for multi-agent development",
        inputSchema: {
          type: "object",
          properties: {
            name: {
              type: "string",
              description: "Project name",
            },
            path: {
              type: "string",
              description: "Absolute path to the project",
            },
            description: {
              type: "string",
              description: "Project description",
            },
            max_agents: {
              type: "number",
              description: "Maximum agents for this project",
            },
            allow_remote: {
              type: "boolean",
              description: "Allow agents from remote machines",
            },
          },
          required: ["name", "path"],
        },
      },

      // LDAP Configuration
      {
        name: "get_ldap_config",
        description: "[Manager] Get current LDAP configuration",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },
      {
        name: "configure_ldap",
        description: "[Manager] Configure LDAP authentication for trust management",
        inputSchema: {
          type: "object",
          properties: {
            enabled: {
              type: "boolean",
              description: "Enable LDAP authentication",
            },
            url: {
              type: "string",
              description: "LDAP server URL (e.g., ldap://192.168.2.100:389)",
            },
            base_dn: {
              type: "string",
              description: "Base DN for searches (e.g., dc=example,dc=com)",
            },
            bind_dn: {
              type: "string",
              description: "DN for binding to LDAP",
            },
            bind_password: {
              type: "string",
              description: "Password for binding",
            },
            agent_group_dn: {
              type: "string",
              description: "DN of group whose members can be agents",
            },
            manager_group_dn: {
              type: "string",
              description: "DN of group whose members can be managers",
            },
          },
          required: ["enabled"],
        },
      },

      // Extended Dashboard
      {
        name: "manager_dashboard",
        description: "[Manager] Get extended dashboard with machine and trust information",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },
    ],
  };
});

// Handle tool calls
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  const formatResponse = (result: { success: boolean; data?: unknown; error?: string }) => ({
    content: [
      {
        type: "text" as const,
        text: JSON.stringify(result.success ? result.data : { error: result.error }, null, 2),
      },
    ],
  });

  switch (name) {
    case "register_agent": {
      const { name: agentName, role, capabilities = [] } = args as {
        name: string;
        role: string;
        capabilities?: string[];
      };

      const result = await apiCall<{ agentId: string; token: string }>("POST", "/agents/register", {
        name: agentName,
        role,
        capabilities,
        machineId: MACHINE_ID,
      });

      if (result.success && result.data) {
        registeredAgentId = result.data.agentId;
        return formatResponse({
          success: true,
          data: {
            message: "Agent registered successfully",
            agentId: registeredAgentId,
            serverUrl: SERVER_URL,
          },
        });
      }
      return formatResponse(result);
    }

    case "heartbeat": {
      if (!registeredAgentId) {
        return formatResponse({ success: false, error: "Agent not registered. Call register_agent first." });
      }

      const { status = "idle" } = (args as { status?: string }) || {};
      const result = await apiCall("POST", `/agents/${registeredAgentId}/heartbeat`, { status });
      return formatResponse(result);
    }

    case "list_agents": {
      const result = await apiCall("GET", "/agents");
      return formatResponse(result);
    }

    case "create_task": {
      const { title, description, priority, tags, assign_to } = args as {
        title: string;
        description: string;
        priority?: string;
        tags?: string[];
        assign_to?: string;
      };

      const result = await apiCall("POST", "/tasks", {
        title,
        description,
        priority,
        tags,
        assignTo: assign_to,
      });
      return formatResponse(result);
    }

    case "assign_task": {
      const { task_id, agent_id } = args as { task_id: string; agent_id: string };
      const result = await apiCall("POST", `/tasks/${task_id}/assign`, { agentId: agent_id });
      return formatResponse(result);
    }

    case "list_tasks": {
      const { status, assigned_to, tag } = (args as {
        status?: string;
        assigned_to?: string;
        tag?: string;
      }) || {};

      const params = new URLSearchParams();
      if (status) params.set("status", status);
      if (assigned_to) params.set("assignedTo", assigned_to);
      if (tag) params.set("tag", tag);

      const queryString = params.toString();
      const result = await apiCall("GET", `/tasks${queryString ? `?${queryString}` : ""}`);
      return formatResponse(result);
    }

    case "get_task": {
      const { task_id } = args as { task_id: string };
      const result = await apiCall("GET", `/tasks/${task_id}`);
      return formatResponse(result);
    }

    case "get_my_tasks": {
      if (!registeredAgentId) {
        return formatResponse({ success: false, error: "Agent not registered. Call register_agent first." });
      }
      const result = await apiCall("GET", `/tasks?assignedTo=${registeredAgentId}`);
      return formatResponse(result);
    }

    case "claim_task": {
      if (!registeredAgentId) {
        return formatResponse({ success: false, error: "Agent not registered. Call register_agent first." });
      }
      const { task_id } = args as { task_id: string };
      const result = await apiCall("POST", `/tasks/${task_id}/claim`);
      return formatResponse(result);
    }

    case "submit_result": {
      const { task_id, result: taskResult, success } = args as {
        task_id: string;
        result: string;
        success: boolean;
      };
      const result = await apiCall("POST", `/tasks/${task_id}/submit`, {
        result: taskResult,
        success,
      });
      return formatResponse(result);
    }

    case "dashboard": {
      const result = await apiCall("GET", "/dashboard");
      return formatResponse(result);
    }

    // ============ Manager Tools ============

    case "list_trusted_machines": {
      const result = await apiCall("GET", "/trust/machines");
      return formatResponse(result);
    }

    case "add_trusted_machine": {
      const { hostname, ip_address, trust_level, auth_method, max_agents } = args as {
        hostname: string;
        ip_address: string;
        trust_level?: string;
        auth_method?: string;
        max_agents?: number;
      };

      const result = await apiCall("POST", "/trust/machines", {
        hostname,
        ipAddress: ip_address,
        trustLevel: trust_level || "basic",
        authMethod: auth_method || "token",
        maxAgents: max_agents || 10,
      });
      return formatResponse(result);
    }

    case "update_machine_trust": {
      const { machine_id, trust_level, max_agents, enabled } = args as {
        machine_id: string;
        trust_level?: string;
        max_agents?: number;
        enabled?: boolean;
      };

      const result = await apiCall("PATCH", `/trust/machines/${machine_id}`, {
        trustLevel: trust_level,
        maxAgents: max_agents,
        enabled,
      });
      return formatResponse(result);
    }

    case "remove_trusted_machine": {
      const { machine_id } = args as { machine_id: string };
      const result = await apiCall("DELETE", `/trust/machines/${machine_id}`);
      return formatResponse(result);
    }

    case "invite_agent": {
      const { machine_id, agent_name, role } = args as {
        machine_id: string;
        agent_name: string;
        role: string;
      };

      const result = await apiCall("POST", "/agents/invite", {
        machineId: machine_id,
        agentName: agent_name,
        role,
      });
      return formatResponse(result);
    }

    case "remove_agent": {
      const { agent_id, reason } = args as { agent_id: string; reason?: string };
      const result = await apiCall("DELETE", `/agents/${agent_id}/remove`, { reason });
      return formatResponse(result);
    }

    case "list_projects": {
      const result = await apiCall("GET", "/projects");
      return formatResponse(result);
    }

    case "create_project": {
      const { name, path, description, max_agents, allow_remote } = args as {
        name: string;
        path: string;
        description?: string;
        max_agents?: number;
        allow_remote?: boolean;
      };

      const result = await apiCall("POST", "/projects", {
        name,
        path,
        description,
        settings: {
          maxAgents: max_agents,
          allowRemoteAgents: allow_remote,
        },
      });
      return formatResponse(result);
    }

    case "get_ldap_config": {
      const result = await apiCall("GET", "/config/ldap");
      return formatResponse(result);
    }

    case "configure_ldap": {
      const {
        enabled,
        url,
        base_dn,
        bind_dn,
        bind_password,
        agent_group_dn,
        manager_group_dn,
      } = args as {
        enabled: boolean;
        url?: string;
        base_dn?: string;
        bind_dn?: string;
        bind_password?: string;
        agent_group_dn?: string;
        manager_group_dn?: string;
      };

      const result = await apiCall("PUT", "/config/ldap", {
        enabled,
        url,
        baseDn: base_dn,
        bindDn: bind_dn,
        bindPassword: bind_password,
        agentGroupDn: agent_group_dn,
        managerGroupDn: manager_group_dn,
      });
      return formatResponse(result);
    }

    case "manager_dashboard": {
      const result = await apiCall("GET", "/dashboard/extended");
      return formatResponse(result);
    }

    default:
      return formatResponse({ success: false, error: `Unknown tool: ${name}` });
  }
});

// List resources
server.setRequestHandler(ListResourcesRequestSchema, async () => {
  return {
    resources: [
      {
        uri: "task://config",
        mimeType: "application/json",
        name: "MCP Bridge Configuration",
        description: "Current configuration for this MCP bridge",
      },
    ],
  };
});

// Read resource
server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
  const { uri } = request.params;

  if (uri === "task://config") {
    return {
      contents: [
        {
          uri,
          mimeType: "application/json",
          text: JSON.stringify(
            {
              serverUrl: SERVER_URL,
              agentId: registeredAgentId,
              agentName: AGENT_NAME,
              agentRole: AGENT_ROLE,
              machineId: MACHINE_ID,
              connected: !!AUTH_TOKEN,
            },
            null,
            2
          ),
        },
      ],
    };
  }

  throw new Error(`Resource not found: ${uri}`);
});

// Start server
async function main() {
  // Auto-register if credentials provided
  if (AUTH_TOKEN && AGENT_NAME && !registeredAgentId) {
    console.error(`Auto-registering agent: ${AGENT_NAME} (${AGENT_ROLE})`);
    const result = await apiCall<{ agentId: string }>("POST", "/agents/register", {
      name: AGENT_NAME,
      role: AGENT_ROLE,
      capabilities: [],
      machineId: MACHINE_ID,
    });
    if (result.success && result.data) {
      registeredAgentId = result.data.agentId;
      console.error(`Registered as: ${registeredAgentId}`);
    }
  }

  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("MCP Bridge running on stdio");
  console.error(`Server URL: ${SERVER_URL}`);
  console.error(`Agent ID: ${registeredAgentId || "(not registered)"}`);
}

main().catch((error) => {
  console.error("Fatal error:", error);
  process.exit(1);
});
