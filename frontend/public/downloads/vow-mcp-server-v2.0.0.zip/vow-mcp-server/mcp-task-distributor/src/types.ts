// Shared types for multi-agent task distribution

export type TaskStatus = "pending" | "assigned" | "in_progress" | "completed" | "failed";
export type TaskPriority = "low" | "normal" | "high" | "urgent";

export interface Task {
  id: string;
  title: string;
  description: string;
  priority: TaskPriority;
  assignedTo: string | null;
  status: TaskStatus;
  result: string | null;
  tags: string[];
  parentTaskId: string | null;  // For subtasks
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  deadline: string | null;
}

export type AgentRole =
  | "manager"
  | "developer"
  | "reviewer"
  | "tester"
  | "documenter"
  | "analyst"
  | "architect"
  | "devops"
  | "general";

export type AgentStatus = "idle" | "busy" | "offline";

export interface Agent {
  id: string;
  name: string;
  role: AgentRole;
  capabilities: string[];
  status: AgentStatus;
  currentTaskId: string | null;
  machineId: string;
  lastHeartbeat: string;
  registeredAt: string;
}

export interface TaskAssignment {
  taskId: string;
  agentId: string;
  assignedAt: string;
  assignedBy: string;
}

export interface TaskResult {
  taskId: string;
  agentId: string;
  success: boolean;
  result: string;
  submittedAt: string;
}

export interface ServerConfig {
  host: string;
  port: number;
  authToken: string;
}

// API Request/Response types
export interface RegisterAgentRequest {
  name: string;
  role: AgentRole;
  capabilities: string[];
  machineId: string;
}

export interface CreateTaskRequest {
  title: string;
  description: string;
  priority?: TaskPriority;
  tags?: string[];
  parentTaskId?: string;
  assignTo?: string;
  deadline?: string;
}

export interface AssignTaskRequest {
  taskId: string;
  agentId: string;
}

export interface SubmitResultRequest {
  taskId: string;
  result: string;
  success: boolean;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
}

// SSE Event types
export type SSEEventType =
  | "task_created"
  | "task_assigned"
  | "task_started"
  | "task_completed"
  | "task_failed"
  | "agent_registered"
  | "agent_status_changed"
  | "heartbeat";

export interface SSEEvent {
  type: SSEEventType;
  timestamp: string;
  data: unknown;
}

// Trust and Machine Management Types
export type TrustLevel = "none" | "basic" | "elevated" | "full";
export type AuthMethod = "token" | "ldap" | "certificate";

export interface TrustedMachine {
  id: string;
  hostname: string;
  ipAddress: string;
  trustLevel: TrustLevel;
  authMethod: AuthMethod;
  publicKey?: string;
  ldapDn?: string;
  addedBy: string;
  addedAt: string;
  lastSeen: string;
  maxAgents: number;
  currentAgents: number;
  isOnline: boolean;
}

export interface MachineRegistration {
  hostname: string;
  ipAddress: string;
  publicKey?: string;
  requestedTrustLevel: TrustLevel;
  authMethod: AuthMethod;
}

export interface TrustRequest {
  id: string;
  fromMachine: MachineRegistration;
  status: "pending" | "approved" | "rejected";
  requestedAt: string;
  reviewedBy?: string;
  reviewedAt?: string;
}

// LDAP Configuration
export interface LDAPConfig {
  enabled: boolean;
  url: string;
  baseDn: string;
  bindDn: string;
  bindPassword: string;
  userSearchFilter: string;
  groupSearchFilter: string;
  agentGroupDn?: string;
  managerGroupDn?: string;
}

// Project Management
export interface Project {
  id: string;
  name: string;
  path: string;
  description?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  settings: ProjectSettings;
}

export interface ProjectSettings {
  maxAgents: number;
  allowRemoteAgents: boolean;
  requiredTrustLevel: TrustLevel;
  autoAssignTasks: boolean;
  defaultAgentRoles: AgentRole[];
}

// Manager-specific requests
export interface InviteAgentRequest {
  machineId: string;
  agentName: string;
  role: AgentRole;
  capabilities?: string[];
}

export interface RemoveAgentRequest {
  agentId: string;
  reason?: string;
}

export interface AddTrustedMachineRequest {
  hostname: string;
  ipAddress: string;
  trustLevel: TrustLevel;
  authMethod: AuthMethod;
  maxAgents: number;
  publicKey?: string;
  ldapDn?: string;
}

export interface UpdateTrustRequest {
  machineId: string;
  trustLevel?: TrustLevel;
  maxAgents?: number;
  enabled?: boolean;
}

// Manager permissions
export const MANAGER_PERMISSIONS = [
  "manage_agents",
  "manage_tasks",
  "manage_trust",
  "manage_projects",
  "view_dashboard",
  "configure_ldap",
] as const;

export type ManagerPermission = typeof MANAGER_PERMISSIONS[number];
