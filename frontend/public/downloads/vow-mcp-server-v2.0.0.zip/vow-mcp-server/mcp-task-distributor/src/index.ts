#!/usr/bin/env node
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ListResourcesRequestSchema,
  ReadResourceRequestSchema,
} from "@modelcontextprotocol/sdk/types.js";

// Task types
interface Task {
  id: string;
  title: string;
  description: string;
  assignedTo: string | null;
  status: "pending" | "in_progress" | "completed" | "failed";
  result: string | null;
  createdAt: string;
  updatedAt: string;
}

// Worker types
type WorkerRole = "data-analyst" | "code-generator" | "doc-writer";

interface Worker {
  id: string;
  role: WorkerRole;
  name: string;
  status: "idle" | "busy";
  currentTaskId: string | null;
}

// In-memory storage
const tasks: Map<string, Task> = new Map();
const workers: Map<string, Worker> = new Map([
  ["worker1", { id: "worker1", role: "data-analyst", name: "Worker1 (Data Analyst)", status: "idle", currentTaskId: null }],
  ["worker2", { id: "worker2", role: "code-generator", name: "Worker2 (Code Generator)", status: "idle", currentTaskId: null }],
  ["worker3", { id: "worker3", role: "doc-writer", name: "Worker3 (Doc Writer)", status: "idle", currentTaskId: null }],
]);

let taskIdCounter = 1;

function generateTaskId(): string {
  return `task-${taskIdCounter++}`;
}

function getCurrentTimestamp(): string {
  return new Date().toISOString();
}

// Create MCP Server
const server = new Server(
  {
    name: "task-distributor",
    version: "1.0.0",
  },
  {
    capabilities: {
      tools: {},
      resources: {},
    },
  }
);

// List available tools
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "assign_task",
        description: "Create and assign a new task to a specific worker. Returns task ID and assignment status.",
        inputSchema: {
          type: "object",
          properties: {
            title: {
              type: "string",
              description: "Brief title of the task",
            },
            description: {
              type: "string",
              description: "Detailed description of what needs to be done",
            },
            worker_id: {
              type: "string",
              enum: ["worker1", "worker2", "worker3"],
              description: "ID of the worker to assign (worker1=data-analyst, worker2=code-generator, worker3=doc-writer)",
            },
          },
          required: ["title", "description", "worker_id"],
        },
      },
      {
        name: "list_pending_tasks",
        description: "Get a list of all tasks that are pending or in progress",
        inputSchema: {
          type: "object",
          properties: {
            status_filter: {
              type: "string",
              enum: ["all", "pending", "in_progress"],
              description: "Filter tasks by status (default: all)",
            },
          },
        },
      },
      {
        name: "submit_result",
        description: "Submit the result for a completed task. Called by workers when they finish a task.",
        inputSchema: {
          type: "object",
          properties: {
            task_id: {
              type: "string",
              description: "ID of the task to submit result for",
            },
            result: {
              type: "string",
              description: "The result/output of the completed task",
            },
            success: {
              type: "boolean",
              description: "Whether the task was completed successfully",
            },
          },
          required: ["task_id", "result", "success"],
        },
      },
      {
        name: "get_task_status",
        description: "Get detailed status information for a specific task",
        inputSchema: {
          type: "object",
          properties: {
            task_id: {
              type: "string",
              description: "ID of the task to check",
            },
          },
          required: ["task_id"],
        },
      },
      {
        name: "list_workers",
        description: "Get a list of all workers and their current status",
        inputSchema: {
          type: "object",
          properties: {},
        },
      },
      {
        name: "claim_task",
        description: "Called by a worker to claim and start working on a pending task assigned to them",
        inputSchema: {
          type: "object",
          properties: {
            task_id: {
              type: "string",
              description: "ID of the task to claim",
            },
            worker_id: {
              type: "string",
              description: "ID of the worker claiming the task",
            },
          },
          required: ["task_id", "worker_id"],
        },
      },
      {
        name: "get_my_tasks",
        description: "Get all tasks assigned to a specific worker",
        inputSchema: {
          type: "object",
          properties: {
            worker_id: {
              type: "string",
              description: "ID of the worker",
            },
          },
          required: ["worker_id"],
        },
      },
    ],
  };
});

// Handle tool calls
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  switch (name) {
    case "assign_task": {
      const { title, description, worker_id } = args as {
        title: string;
        description: string;
        worker_id: string;
      };

      const worker = workers.get(worker_id);
      if (!worker) {
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify({ error: `Worker ${worker_id} not found` }, null, 2),
            },
          ],
        };
      }

      const taskId = generateTaskId();
      const now = getCurrentTimestamp();
      const task: Task = {
        id: taskId,
        title,
        description,
        assignedTo: worker_id,
        status: "pending",
        result: null,
        createdAt: now,
        updatedAt: now,
      };

      tasks.set(taskId, task);

      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                success: true,
                task_id: taskId,
                assigned_to: worker.name,
                message: `Task "${title}" assigned to ${worker.name}`,
              },
              null,
              2
            ),
          },
        ],
      };
    }

    case "list_pending_tasks": {
      const { status_filter = "all" } = (args as { status_filter?: string }) || {};

      const filteredTasks = Array.from(tasks.values()).filter((task) => {
        if (status_filter === "all") {
          return task.status === "pending" || task.status === "in_progress";
        }
        return task.status === status_filter;
      });

      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                count: filteredTasks.length,
                tasks: filteredTasks.map((t) => ({
                  id: t.id,
                  title: t.title,
                  status: t.status,
                  assigned_to: t.assignedTo,
                  created_at: t.createdAt,
                })),
              },
              null,
              2
            ),
          },
        ],
      };
    }

    case "submit_result": {
      const { task_id, result, success } = args as {
        task_id: string;
        result: string;
        success: boolean;
      };

      const task = tasks.get(task_id);
      if (!task) {
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify({ error: `Task ${task_id} not found` }, null, 2),
            },
          ],
        };
      }

      task.status = success ? "completed" : "failed";
      task.result = result;
      task.updatedAt = getCurrentTimestamp();

      // Update worker status
      if (task.assignedTo) {
        const worker = workers.get(task.assignedTo);
        if (worker && worker.currentTaskId === task_id) {
          worker.status = "idle";
          worker.currentTaskId = null;
        }
      }

      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                success: true,
                task_id,
                new_status: task.status,
                message: `Task ${task_id} marked as ${task.status}`,
              },
              null,
              2
            ),
          },
        ],
      };
    }

    case "get_task_status": {
      const { task_id } = args as { task_id: string };

      const task = tasks.get(task_id);
      if (!task) {
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify({ error: `Task ${task_id} not found` }, null, 2),
            },
          ],
        };
      }

      const worker = task.assignedTo ? workers.get(task.assignedTo) : null;

      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                id: task.id,
                title: task.title,
                description: task.description,
                status: task.status,
                assigned_to: worker?.name || null,
                result: task.result,
                created_at: task.createdAt,
                updated_at: task.updatedAt,
              },
              null,
              2
            ),
          },
        ],
      };
    }

    case "list_workers": {
      const workerList = Array.from(workers.values()).map((w) => ({
        id: w.id,
        name: w.name,
        role: w.role,
        status: w.status,
        current_task: w.currentTaskId,
      }));

      return {
        content: [
          {
            type: "text",
            text: JSON.stringify({ workers: workerList }, null, 2),
          },
        ],
      };
    }

    case "claim_task": {
      const { task_id, worker_id } = args as {
        task_id: string;
        worker_id: string;
      };

      const task = tasks.get(task_id);
      if (!task) {
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify({ error: `Task ${task_id} not found` }, null, 2),
            },
          ],
        };
      }

      if (task.assignedTo !== worker_id) {
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify(
                { error: `Task ${task_id} is not assigned to ${worker_id}` },
                null,
                2
              ),
            },
          ],
        };
      }

      if (task.status !== "pending") {
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify(
                { error: `Task ${task_id} is not pending (current status: ${task.status})` },
                null,
                2
              ),
            },
          ],
        };
      }

      const worker = workers.get(worker_id);
      if (!worker) {
        return {
          content: [
            {
              type: "text",
              text: JSON.stringify({ error: `Worker ${worker_id} not found` }, null, 2),
            },
          ],
        };
      }

      task.status = "in_progress";
      task.updatedAt = getCurrentTimestamp();
      worker.status = "busy";
      worker.currentTaskId = task_id;

      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                success: true,
                task_id,
                title: task.title,
                description: task.description,
                message: `Task claimed. Please complete: ${task.description}`,
              },
              null,
              2
            ),
          },
        ],
      };
    }

    case "get_my_tasks": {
      const { worker_id } = args as { worker_id: string };

      const myTasks = Array.from(tasks.values()).filter(
        (t) => t.assignedTo === worker_id
      );

      return {
        content: [
          {
            type: "text",
            text: JSON.stringify(
              {
                worker_id,
                tasks: myTasks.map((t) => ({
                  id: t.id,
                  title: t.title,
                  status: t.status,
                  description: t.description,
                })),
              },
              null,
              2
            ),
          },
        ],
      };
    }

    default:
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify({ error: `Unknown tool: ${name}` }, null, 2),
          },
        ],
      };
  }
});

// List resources (task board overview)
server.setRequestHandler(ListResourcesRequestSchema, async () => {
  return {
    resources: [
      {
        uri: "task://board/overview",
        mimeType: "application/json",
        name: "Task Board Overview",
        description: "Current status of all tasks and workers",
      },
    ],
  };
});

// Read resource
server.setRequestHandler(ReadResourceRequestSchema, async (request) => {
  const { uri } = request.params;

  if (uri === "task://board/overview") {
    const allTasks = Array.from(tasks.values());
    const allWorkers = Array.from(workers.values());

    const overview = {
      timestamp: getCurrentTimestamp(),
      summary: {
        total_tasks: allTasks.length,
        pending: allTasks.filter((t) => t.status === "pending").length,
        in_progress: allTasks.filter((t) => t.status === "in_progress").length,
        completed: allTasks.filter((t) => t.status === "completed").length,
        failed: allTasks.filter((t) => t.status === "failed").length,
      },
      workers: allWorkers.map((w) => ({
        id: w.id,
        name: w.name,
        role: w.role,
        status: w.status,
      })),
      recent_tasks: allTasks.slice(-5).map((t) => ({
        id: t.id,
        title: t.title,
        status: t.status,
        assigned_to: t.assignedTo,
      })),
    };

    return {
      contents: [
        {
          uri,
          mimeType: "application/json",
          text: JSON.stringify(overview, null, 2),
        },
      ],
    };
  }

  throw new Error(`Resource not found: ${uri}`);
});

// Start server
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("Task Distributor MCP Server running on stdio");
}

main().catch((error) => {
  console.error("Fatal error:", error);
  process.exit(1);
});
