#!/bin/bash
#===============================================================================
# VOW MCP Task Distribution Server Setup
#===============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║         VOW MCP Task Distribution Server Setup             ║${NC}"
echo -e "${CYAN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}Error: Node.js is required but not installed.${NC}"
    echo "Please install Node.js 18+ from https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${YELLOW}Warning: Node.js 18+ recommended (found v$(node -v))${NC}"
fi

echo -e "${GREEN}✓ Node.js $(node -v) detected${NC}"

# Install dependencies
echo ""
echo "Installing dependencies..."
cd mcp-task-distributor
npm install

# Build TypeScript
echo ""
echo "Building server..."
npm run build

# Generate auth token
AUTH_TOKEN="mcp-$(openssl rand -hex 16 2>/dev/null || cat /dev/urandom | tr -dc 'a-f0-9' | head -c 32)"

# Create config directory
mkdir -p ../config
cat > ../config/server.env << EOF
# MCP Task Distribution Server Configuration
TASK_SERVER_PORT=3456
TASK_SERVER_HOST=0.0.0.0
TASK_SERVER_TOKEN=$AUTH_TOKEN
EOF

echo ""
echo -e "${GREEN}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                    Setup Complete!                          ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "Server Token: ${YELLOW}$AUTH_TOKEN${NC}"
echo ""
echo "To start the server:"
echo -e "  ${CYAN}cd $(pwd) && source ../config/server.env && npm run start:server${NC}"
echo ""
echo "Or use the start script:"
echo -e "  ${CYAN}../start-server.sh${NC}"
echo ""
echo "Server will be available at:"
echo -e "  ${CYAN}http://localhost:3456${NC}"
echo ""
echo "Add this token to your VOW dashboard Multi-Agent settings."
