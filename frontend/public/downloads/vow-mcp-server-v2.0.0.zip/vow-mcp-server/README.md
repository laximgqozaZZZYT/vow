# VOW MCP Task Distribution Server

Multi-agent task distribution server for coordinating Claude Code agents.

## Quick Start

```bash
# 1. Run setup
./setup.sh

# 2. Start server
./start-server.sh

# 3. Server runs at http://localhost:3456
```

## Configuration

After setup, configuration is stored in `config/server.env`:
- `TASK_SERVER_PORT` - Server port (default: 3456)
- `TASK_SERVER_HOST` - Bind address (default: 0.0.0.0)
- `TASK_SERVER_TOKEN` - Authentication token

## Connecting Claude Code Agents

1. Copy `mcp-config.template.json` to `~/.claude/mcp-config.json`
2. Update the paths and token
3. Start Claude Code: `claude --mcp-config ~/.claude/mcp-config.json`

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check |
| `/agents` | GET | List all agents |
| `/agents` | POST | Register new agent |
| `/tasks` | GET | List all tasks |
| `/tasks` | POST | Create new task |
| `/tasks/:id/assign` | POST | Assign task to agent |
| `/tasks/:id/claim` | POST | Agent claims a task |
| `/tasks/:id/complete` | POST | Submit task result |
| `/dashboard` | GET | Get statistics |
| `/events` | GET | SSE event stream |

## VOW Dashboard Integration

1. Open VOW Dashboard → Agents section
2. Click settings (gear icon)
3. Add new server:
   - Name: Local MCP Server
   - URL: http://localhost:3456
   - Token: (from setup)
4. Enable and connect

## Requirements

- Node.js 18+
- npm

## License

MIT
