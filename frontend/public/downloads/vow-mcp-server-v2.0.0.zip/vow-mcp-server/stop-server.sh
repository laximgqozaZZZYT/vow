#!/bin/bash
pkill -f "node.*server.js" && echo "Server stopped." || echo "No server running."
