#!/bin/bash
cd "$(dirname "${BASH_SOURCE[0]}")"

if [ -f config/server.env ]; then
    source config/server.env
fi

export TASK_SERVER_PORT="${TASK_SERVER_PORT:-3456}"
export TASK_SERVER_HOST="${TASK_SERVER_HOST:-0.0.0.0}"

if [ -z "$TASK_SERVER_TOKEN" ]; then
    export TASK_SERVER_TOKEN="mcp-$(openssl rand -hex 16 2>/dev/null || echo "default-token-$(date +%s)")"
    echo "Generated token: $TASK_SERVER_TOKEN"
fi

echo "Starting MCP Task Distribution Server..."
echo "  Port: $TASK_SERVER_PORT"
echo "  Host: $TASK_SERVER_HOST"
echo ""

cd mcp-task-distributor
node build/server.js
