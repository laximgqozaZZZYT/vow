/**
 * Slack Block Kit Message Builder
 *
 * Utility for building rich Slack messages using Block Kit.
 * Ported from Python implementation.
 */
/**
 * Utility class for building Slack Block Kit messages.
 */
export class SlackBlockBuilder {
    /**
     * Generate a text-based progress bar with color coding.
     *
     * @param progressRate - Progress percentage (0-100+)
     * @returns String with colored block characters (10 segments)
     *
     * Color coding:
     * - >= 100%: 🟩 (green)
     * - 75-99%: 🟦 (blue)
     * - 50-74%: 🟨 (yellow)
     * - < 50%: 🟥 (red)
     *
     * Empty segments use ⬜
     */
    static progressBar(progressRate) {
        // Calculate filled segments: min(10, max(0, floor(progressRate / 10)))
        const filledSegments = Math.min(10, Math.max(0, Math.floor(progressRate / 10)));
        const emptySegments = 10 - filledSegments;
        // Determine color based on progressRate
        let filledChar;
        if (progressRate >= 100) {
            filledChar = '🟩'; // Green
        }
        else if (progressRate >= 75) {
            filledChar = '🟦'; // Blue
        }
        else if (progressRate >= 50) {
            filledChar = '🟨'; // Yellow
        }
        else {
            filledChar = '🟥'; // Red
        }
        const emptyChar = '⬜';
        // Build progress bar string
        return filledChar.repeat(filledSegments) + emptyChar.repeat(emptySegments);
    }
    /**
     * Generate streak display string with appropriate emoji.
     *
     * @param streak - Current streak count (number of consecutive days)
     * @returns Formatted string with streak count and emoji
     */
    static streakDisplay(streak) {
        if (streak <= 0) {
            return '';
        }
        else if (streak >= 7) {
            return `🔥${streak}日`;
        }
        else if (streak >= 3) {
            return `✨${streak}日`;
        }
        else {
            return `${streak}日`;
        }
    }
    /**
     * Create a section block.
     */
    static section(text, accessory) {
        const block = {
            type: 'section',
            text: {
                type: 'mrkdwn',
                text,
            },
        };
        if (accessory) {
            block['accessory'] = accessory;
        }
        return block;
    }
    /**
     * Create a divider block.
     */
    static divider() {
        return { type: 'divider' };
    }
    /**
     * Create a header block.
     */
    static header(text) {
        return {
            type: 'header',
            text: {
                type: 'plain_text',
                text,
                emoji: true,
            },
        };
    }
    /**
     * Create an actions block.
     */
    static actions(elements) {
        return {
            type: 'actions',
            elements,
        };
    }
    /**
     * Create a button element.
     */
    static button(text, actionId, value, style, url) {
        const button = {
            type: 'button',
            text: {
                type: 'plain_text',
                text,
                emoji: true,
            },
            action_id: actionId,
            value,
        };
        if (style) {
            button['style'] = style;
        }
        if (url) {
            button['url'] = url;
        }
        return button;
    }
    /**
     * Create a context block.
     */
    static context(elements) {
        return {
            type: 'context',
            elements: elements.map((text) => ({
                type: 'mrkdwn',
                text,
            })),
        };
    }
    // ========================================================================
    // Weekly Report Messages
    // ========================================================================
    /**
     * Build formatted weekly report with View Full Report button.
     *
     * @param report - Weekly report data
     * @param appUrl - URL to the full report in the app
     * @returns List of Block Kit blocks
     */
    static weeklyReport(report, appUrl) {
        // Determine emoji based on completion rate
        let emoji;
        let message;
        if (report.completionRate >= 80) {
            emoji = '🏆';
            message = '素晴らしい一週間でした！';
        }
        else if (report.completionRate >= 60) {
            emoji = '💪';
            message = '良い進捗です！';
        }
        else if (report.completionRate >= 40) {
            emoji = '📈';
            message = '勢いをつけていきましょう！';
        }
        else {
            emoji = '🌱';
            message = '一歩一歩が大切です！';
        }
        // Format dates
        const formatDate = (date) => {
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            return `${month}/${day}`;
        };
        const blocks = [
            SlackBlockBuilder.header(`${emoji} 週次レポート`),
            SlackBlockBuilder.section(`*${formatDate(report.weekStart)} - ${formatDate(report.weekEnd)}*\n${message}`),
            SlackBlockBuilder.divider(),
            SlackBlockBuilder.section(`*📊 達成率:* ${Math.round(report.completionRate)}%\n` +
                `*✅ 完了した習慣:* ${report.completedHabits}/${report.totalHabits}\n` +
                `*🔥 最長ストリーク:* ${report.bestStreak}日 (${report.bestStreakHabit})`),
        ];
        if (report.habitsNeedingAttention.length > 0) {
            const attentionList = report.habitsNeedingAttention
                .slice(0, 3)
                .map((h) => `• ${h}`)
                .join('\n');
            blocks.push(SlackBlockBuilder.divider());
            blocks.push(SlackBlockBuilder.section(`*⚠️ 注意が必要な習慣:*\n${attentionList}`));
        }
        blocks.push(SlackBlockBuilder.divider());
        blocks.push(SlackBlockBuilder.actions([
            {
                type: 'button',
                text: {
                    type: 'plain_text',
                    text: '詳細レポートを見る',
                    emoji: true,
                },
                url: appUrl,
                action_id: 'view_full_report',
            },
        ]));
        return blocks;
    }
    /**
     * Build message for users with no activity.
     *
     * @param appUrl - URL to the app
     * @returns List of Block Kit blocks
     */
    static weeklyReportNoActivity(appUrl) {
        return [
            SlackBlockBuilder.header('📊 週次レポート'),
            SlackBlockBuilder.section('今週は習慣を記録していませんでした。' + '大丈夫です - 毎週が新しいスタートです！🌱'),
            SlackBlockBuilder.actions([
                {
                    type: 'button',
                    text: {
                        type: 'plain_text',
                        text: '習慣を追加',
                        emoji: true,
                    },
                    url: appUrl,
                    action_id: 'add_habits',
                    style: 'primary',
                },
            ]),
        ];
    }
    /**
     * Build message for user not connected to Slack.
     */
    static notConnected() {
        return [
            SlackBlockBuilder.section('🔗 SlackアカウントがまだVOWに接続されていません。\n' +
                '設定画面から接続して、Slackコマンドを使えるようにしましょう！'),
        ];
    }
    /**
     * Build error message with optional suggestions.
     */
    static errorMessage(message, suggestions) {
        const blocks = [SlackBlockBuilder.section(`❌ ${message}`)];
        if (suggestions && suggestions.length > 0) {
            const suggestionText = suggestions.map((s) => `• ${s}`).join('\n');
            blocks.push(SlackBlockBuilder.section(`*もしかして:*\n${suggestionText}`));
        }
        return blocks;
    }
    // ========================================================================
    // Habit Completion Messages
    // ========================================================================
    /**
     * Build confirmation message after habit completion.
     *
     * @param habitName - Name of the completed habit
     * @param streak - Current streak count
     * @returns List of Block Kit blocks
     */
    static habitCompletionConfirm(habitName, streak) {
        const streakEmoji = streak >= 7 ? '🔥' : streak >= 3 ? '✨' : '👍';
        const streakText = streak > 1 ? `${streakEmoji} ${streak}日連続達成！` : '';
        return [SlackBlockBuilder.section(`✅ *${habitName}* を完了しました！ ${streakText}`)];
    }
    /**
     * Build message for already completed habit.
     */
    static habitAlreadyCompleted(habitName) {
        return [
            SlackBlockBuilder.section(`ℹ️ *${habitName}* は今日すでに完了しています。その調子で頑張りましょう！`),
        ];
    }
    /**
     * Build message for habit not found.
     */
    static habitNotFound(habitName, similarHabits) {
        return SlackBlockBuilder.errorMessage(`*${habitName}* という名前の習慣が見つかりませんでした`, similarHabits);
    }
    /**
     * Build message for skipped habit.
     */
    static habitSkipped(habitName) {
        return [
            SlackBlockBuilder.section(`⏭️ *${habitName}* を今日はスキップしました。これ以上リマインドしません。`),
        ];
    }
    /**
     * Build message for remind later.
     */
    static habitRemindLater(habitName, minutes = 60) {
        return [
            SlackBlockBuilder.section(`⏰ 了解しました！${minutes}分後に *${habitName}* をリマインドします。`),
        ];
    }
    // ========================================================================
    // Habit List and Status Messages
    // ========================================================================
    /**
     * Build interactive list of habits with completion buttons.
     *
     * @param habits - List of habit objects with id, name, streak, completed, goal_name
     * @param showButtons - Whether to show completion buttons
     * @returns List of Block Kit blocks
     */
    static habitList(habits, showButtons = true) {
        if (!habits || habits.length === 0) {
            return [
                SlackBlockBuilder.section('📝 まだ習慣が登録されていません。アプリで習慣を追加して始めましょう！'),
            ];
        }
        const blocks = [SlackBlockBuilder.header('📋 あなたの習慣')];
        // Group by goal
        const goals = {};
        for (const habit of habits) {
            const goal = habit.goal_name ?? 'ゴールなし';
            if (!goals[goal]) {
                goals[goal] = [];
            }
            goals[goal].push(habit);
        }
        for (const [goalName, goalHabits] of Object.entries(goals)) {
            blocks.push(SlackBlockBuilder.section(`*${goalName}*`));
            for (const habit of goalHabits) {
                const status = habit.completed ? '✅' : '⬜';
                const streak = habit.streak ?? 0;
                const streakText = streak > 0 ? ` 🔥${streak}日` : '';
                const text = `${status} ${habit.name}${streakText}`;
                if (showButtons && !habit.completed) {
                    blocks.push({
                        type: 'section',
                        text: {
                            type: 'mrkdwn',
                            text,
                        },
                        accessory: SlackBlockBuilder.button('完了', `habit_done_${habit.id}`, habit.id, 'primary'),
                    });
                }
                else {
                    blocks.push(SlackBlockBuilder.section(text));
                }
            }
            blocks.push(SlackBlockBuilder.divider());
        }
        return blocks;
    }
    /**
     * Build status summary with habit details.
     *
     * @param completed - Number of completed habits
     * @param total - Total number of habits
     * @param habits - List of habit objects
     * @returns List of Block Kit blocks
     */
    static habitStatus(completed, total, habits) {
        const percentage = total > 0 ? (completed / total) * 100 : 0;
        // Progress bar
        const filled = Math.floor(percentage / 10);
        const progress = '█'.repeat(filled) + '░'.repeat(10 - filled);
        const blocks = [
            SlackBlockBuilder.header('📊 今日の進捗'),
            SlackBlockBuilder.section(`*${completed}/${total}* 習慣を完了 (${Math.round(percentage)}%)\n\`${progress}\``),
            SlackBlockBuilder.divider(),
        ];
        // List incomplete habits
        const incomplete = habits.filter((h) => !h.completed);
        if (incomplete.length > 0) {
            blocks.push(SlackBlockBuilder.section('*今日の残り:*'));
            for (const habit of incomplete.slice(0, 5)) {
                blocks.push({
                    type: 'section',
                    text: {
                        type: 'mrkdwn',
                        text: `⬜ ${habit.name}`,
                    },
                    accessory: SlackBlockBuilder.button('完了', `habit_done_${habit.id}`, habit.id, 'primary'),
                });
            }
            if (incomplete.length > 5) {
                blocks.push(SlackBlockBuilder.context([`...他${incomplete.length - 5}件`]));
            }
        }
        return blocks;
    }
    /**
     * Build help message with available commands.
     */
    static availableCommands() {
        return [
            SlackBlockBuilder.header('📚 利用可能なコマンド'),
            SlackBlockBuilder.section('*`/habit-done [名前]`*\n' +
                '習慣を完了としてマークします。名前を省略すると、選択リストが表示されます。'),
            SlackBlockBuilder.section('*`/habit-status`*\n' + '今日の進捗と残りの習慣を確認します。'),
            SlackBlockBuilder.section('*`/habit-list`*\n' + 'ゴール別にグループ化された習慣一覧を表示します。'),
            SlackBlockBuilder.section('*`/habit-dashboard`*\n' + '今日の進捗ダッシュボードを表示します。'),
        ];
    }
    // ========================================================================
    // Dashboard Messages
    // ========================================================================
    /**
     * Build dashboard message for users with no active habits.
     */
    static dashboardEmpty() {
        return [
            SlackBlockBuilder.header('📊 今日の進捗'),
            SlackBlockBuilder.section('📝 まだ習慣が登録されていません。\nアプリで習慣を追加して始めましょう！'),
        ];
    }
    /**
     * Build error message for dashboard errors.
     */
    static dashboardError(message) {
        return [SlackBlockBuilder.section(`❌ ${message}`)];
    }
}
//# sourceMappingURL=slackBlockBuilder.js.map